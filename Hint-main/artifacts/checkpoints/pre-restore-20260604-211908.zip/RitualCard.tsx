import { useRef } from "react";
import type { RitualCard as RitualCardModel } from "../logic/ritualTypes";

type RitualCardProps = {
  card: RitualCardModel;
  phaseIsChoose: boolean;
  phaseIsReveal: boolean;
  onChoose: (visualId: string) => void;
  onReveal: (visualId: string) => void;
};

export function RitualCard({
  card,
  phaseIsChoose,
  phaseIsReveal,
  onChoose,
  onReveal,
}: RitualCardProps) {
  const lastActivationAt = useRef(0);
  const { transform } = card;
  const canChoose = phaseIsChoose;
  const canReveal = phaseIsReveal && card.selected && !card.revealed;
  const hidden = phaseIsReveal && !card.selected;

  function activateCard() {
    const now = window.performance.now();
    if (now - lastActivationAt.current < 120) return;
    lastActivationAt.current = now;
    if (canChoose) onChoose(card.visualId);
    if (canReveal) onReveal(card.visualId);
  }

  return (
    <button
      type="button"
      aria-label={
        card.revealed
          ? card.hiddenIdentity.name
          : card.selected
            ? "Selected card"
            : "Face-down ritual card"
      }
      disabled={!canChoose && !canReveal}
      onMouseDown={(event) => {
        event.preventDefault();
        activateCard();
      }}
      onTouchStart={(event) => {
        event.preventDefault();
        activateCard();
      }}
      onKeyDown={(event) => {
        if (event.key !== "Enter" && event.key !== " ") return;
        event.preventDefault();
        activateCard();
      }}
      className={`absolute left-1/2 top-1/2 h-[94px] w-[62px] rounded-[9px] outline-none transition-[transform,opacity,filter] duration-1000 ease-[cubic-bezier(.3,.7,.2,1)] will-change-transform sm:h-[118px] sm:w-[78px] ${
        card.selected ? "drop-shadow-[0_0_24px_rgba(134,214,199,0.38)]" : "drop-shadow-[0_15px_24px_rgba(0,0,0,0.52)]"
      } ${hidden ? "pointer-events-none" : ""}`}
      style={{
        opacity: transform.opacity,
        zIndex: transform.zIndex,
        transform: `translate(calc(-50% + ${transform.x}px), calc(-50% + ${transform.y}px)) rotate(${transform.rotate}deg) scale(${transform.scale})`,
      }}
    >
      {card.selected && !card.revealed && (
        <span className="pointer-events-none absolute -inset-2 rounded-[13px] border border-[#86D6C7]/80 shadow-[0_0_28px_rgba(134,214,199,0.32)]" />
      )}

      <span
        className="absolute inset-0 rounded-[9px] transition-transform duration-700 [transform-style:preserve-3d]"
        style={{ transform: card.revealed ? "rotateY(180deg)" : "rotateY(0deg)" }}
      >
        <span className="absolute inset-0 overflow-hidden rounded-[9px] border border-[#CBA866]/28 bg-[linear-gradient(160deg,#172238,#0b1120)] shadow-[inset_0_0_16px_rgba(203,168,102,0.07)] [backface-visibility:hidden]">
          <span className="absolute inset-[9px] rounded-[7px] border border-[#CBA866]/20" />
          <span className="absolute left-1/2 top-1/2 grid h-7 w-7 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full border border-[#CBA866]/28 font-serif text-[11px] text-[#CBA866] sm:h-9 sm:w-9 sm:text-[13px]">
            H
          </span>
          <span className="absolute inset-0 opacity-[0.12] [background-image:radial-gradient(circle_at_20%_22%,white_0_1px,transparent_1px),radial-gradient(circle_at_78%_70%,white_0_1px,transparent_1px)] [background-size:18px_22px]" />
        </span>

        <span className="absolute inset-0 grid place-items-center overflow-hidden rounded-[9px] border border-[#CBA866]/70 bg-[linear-gradient(165deg,#F2ECDE,#dfd0ad)] p-2 text-center text-[#1a1305] shadow-[inset_0_1px_0_rgba(255,255,255,0.72)] [backface-visibility:hidden] [transform:rotateY(180deg)]">
          <span className="absolute inset-[7px] rounded-[7px] border border-[#8a6626]/30" />
          {card.revealed && (
            <span className="relative block">
              <span className="mb-2 block font-sans text-[8px] uppercase tracking-[0.18em] text-[#7c642e]">
                {card.hiddenIdentity.orientation}
              </span>
              <span className="block font-serif text-[12px] leading-tight text-[#1a1305] sm:text-[14px]">
                {card.hiddenIdentity.name}
              </span>
              <span className="mt-2 block font-sans text-[8px] leading-tight text-[#6f6048] sm:text-[9px]">
                {card.hiddenIdentity.keywords.join(" / ")}
              </span>
            </span>
          )}
        </span>
      </span>
    </button>
  );
}
