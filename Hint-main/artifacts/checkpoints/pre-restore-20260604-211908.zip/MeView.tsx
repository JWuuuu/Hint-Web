import { useState } from "react";
import { motion } from "framer-motion";
import { Link } from "wouter";
import {
  Archive,
  Bell,
  BookOpen,
  CalendarDays,
  Clock,
  Download,
  Eraser,
  FileText,
  Heart,
  HelpCircle,
  Mail,
  NotebookPen,
  Palette,
  ShieldCheck,
  Sparkles,
  Star,
  UserRound,
} from "lucide-react";
import { ACCENT, GLASS } from "../hold/atmosphere";
import { AppScreen, GlassPanel, SectionLabel } from "../../components/app/AppChrome";
import { useGetUserStats } from "@workspace/api-client-react";
import { useProfile } from "../../lib/useProfile";
import { getAnonId } from "../../lib/identity";
import { ProfileForm } from "../../components/app/ProfileForm";
import { initialsFrom, zodiacSign } from "./utils";
import { apiUrl } from "../../lib/api";
import { CONTACT_EMAIL, LEGAL_DISCLAIMER } from "../../components/LegalNotice";
import { useLanguage } from "../../lib/i18n";

async function clearLocalHistory(confirmMessage: string) {
  if (!window.confirm(confirmMessage)) return;
  const anonId = getAnonId();

  try {
    await fetch(apiUrl(`/history?anonId=${encodeURIComponent(anonId)}`), {
      method: "DELETE",
    });
  } catch {
    // Local cleanup still works if the API is unavailable.
  }

  try {
    localStorage.clear();
  } catch {
    // No further fallback is available.
  }

  window.location.reload();
}

function ValueRow({
  label,
  value,
  icon: Icon,
}: {
  label: string;
  value: string;
  icon: typeof UserRound;
}) {
  return (
    <div className="flex items-center gap-3 rounded-[8px] border px-3.5 py-3" style={{ borderColor: GLASS.border, background: GLASS.panel }}>
      <Icon size={16} color={ACCENT.aqua} className="shrink-0" />
      <div className="min-w-0">
        <p className="font-sans text-[10px] uppercase tracking-[0.14em]" style={{ color: GLASS.faint }}>
          {label}
        </p>
        <p className="mt-0.5 truncate font-serif text-[14px]" style={{ color: GLASS.text }}>
          {value}
        </p>
      </div>
    </div>
  );
}

function Metric({
  label,
  value,
  icon: Icon,
}: {
  label: string;
  value: string | number;
  icon: typeof Star;
}) {
  return (
    <div className="rounded-[8px] border px-4 py-3" style={{ borderColor: GLASS.border, background: GLASS.panel }}>
      <Icon size={17} color={ACCENT.gold} />
      <p className="mt-2 font-serif text-[20px] tabular-nums" style={{ color: GLASS.text }}>
        {value}
      </p>
      <p className="font-sans text-[11px]" style={{ color: GLASS.faint }}>
        {label}
      </p>
    </div>
  );
}

function ActionLink({
  href,
  label,
  detail,
  icon: Icon,
}: {
  href: string;
  label: string;
  detail: string;
  icon: typeof ShieldCheck;
}) {
  return (
    <Link
      href={href}
      className="flex items-center gap-3 rounded-[8px] border px-3.5 py-3"
      style={{ borderColor: GLASS.border, background: GLASS.panel }}
    >
      <Icon size={16} color={ACCENT.aqua} className="shrink-0" />
      <span className="min-w-0">
        <span className="block font-serif text-[14px]" style={{ color: GLASS.text }}>
          {label}
        </span>
        <span className="block font-sans text-[11px] leading-snug" style={{ color: GLASS.faint }}>
          {detail}
        </span>
      </span>
    </Link>
  );
}

export function MeView() {
  const anonId = getAnonId();
  const { profile, saveProfile, isSaving } = useProfile();
  const { data: stats } = useGetUserStats({ anonId });
  const [editing, setEditing] = useState(false);
  const { language, t } = useLanguage();

  async function handleSave(input: Parameters<typeof saveProfile>[0]) {
    await saveProfile(input);
    setEditing(false);
  }

  const name = profile?.name || t("me.guest");
  const initials = initialsFrom(profile?.name);
  const sign = zodiacSign(profile?.birthDate, language);

  return (
    <AppScreen>
      <motion.header
        initial={{ opacity: 0, y: -6 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: "easeOut" }}
        className="mb-7"
      >
        <p className="font-sans text-[11px] font-medium uppercase tracking-[0.14em]" style={{ color: ACCENT.aqua }}>
          Account
        </p>
        <h1 className="mt-1 font-serif text-[30px] leading-none" style={{ color: GLASS.text }}>
          Me
        </h1>
        <p className="mt-3 max-w-md font-sans text-[13px] leading-relaxed" style={{ color: GLASS.muted }}>
          Profile, memory, limits, and trust controls for your Hint account.
        </p>
      </motion.header>

      {editing ? (
        <section className="mb-8">
          <SectionLabel>Profile</SectionLabel>
          <GlassPanel hero>
            <ProfileForm
              initial={profile}
              submitLabel={t("me.saveChanges")}
              onSubmit={handleSave}
              isSaving={isSaving}
              onCancel={() => setEditing(false)}
            />
          </GlassPanel>
        </section>
      ) : (
        <div className="flex flex-col gap-8">
          <section>
            <SectionLabel>Profile</SectionLabel>
            <GlassPanel hero>
              <div className="flex items-center gap-4">
                <div
                  className="flex h-16 w-16 shrink-0 items-center justify-center rounded-full"
                  style={{
                    background: "var(--hint-me-avatar-bg)",
                    border: `1px solid ${GLASS.borderStrong}`,
                    boxShadow: "var(--hint-me-avatar-shadow)",
                  }}
                >
                  <span className="font-serif text-[18px]" style={{ color: GLASS.text }}>
                    {initials}
                  </span>
                </div>
                <div className="min-w-0 flex-1">
                  <h2 className="truncate font-serif text-[23px]" style={{ color: GLASS.text }}>
                    {name}
                  </h2>
                  <p className="font-sans text-[12px]" style={{ color: GLASS.muted }}>
                    {sign || "Birthday not set"} · Main focus: Self-reflection
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setEditing(true)}
                  className="h-9 rounded-[8px] border px-3 font-sans text-[12px] font-medium"
                  style={{ color: GLASS.text, borderColor: GLASS.border, background: GLASS.panel }}
                >
                  Edit
                </button>
              </div>
              <div className="mt-5 grid gap-3 sm:grid-cols-2">
                <ValueRow icon={UserRound} label="Name" value={name} />
                <ValueRow icon={CalendarDays} label="Birthday" value={profile?.birthDate || "Add birthday"} />
                <ValueRow icon={Clock} label="Birth time" value={profile?.birthTime || "Add birth time"} />
                <ValueRow icon={Heart} label="Personality style" value="Reflective placeholder" />
              </div>
            </GlassPanel>
          </section>

          <section>
            <SectionLabel>Ritual</SectionLabel>
            <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
              <Metric icon={Sparkles} label="Streak" value={`${stats?.nights ?? 0} nights`} />
              <Metric icon={Star} label="Stars" value="0" />
              <Metric icon={FileText} label="Reading credits" value="5 free" />
              <Metric icon={Archive} label="Next reward" value="3 reads" />
            </div>
            <div className="mt-3 grid gap-3 sm:grid-cols-2">
              <ActionLink href="/daily-pull" icon={Bell} label="Reminder" detail="Daily ritual reminder placeholder" />
              <ActionLink href="/rooms" icon={Sparkles} label="Ritual setup" detail="Choose the room before a reading" />
            </div>
          </section>

          <section>
            <SectionLabel>Memory</SectionLabel>
            <div className="grid gap-3 sm:grid-cols-2">
              <ActionLink href="/readings" icon={Archive} label="Saved readings" detail={`${stats?.readings ?? 0} archived readings`} />
              <ActionLink href="/readings" icon={Star} label="Daily cards" detail={`${stats?.pulls ?? 0} saved cards`} />
              <ActionLink href="/daily-pull" icon={BookOpen} label="Deck and meanings" detail="Card meanings and daily references" />
              <ActionLink href="/journal" icon={NotebookPen} label="Journals" detail="Private notes placeholder" />
              <ActionLink href="/me" icon={Heart} label="Mood history" detail="Mood tracking placeholder" />
            </div>
          </section>

          <section>
            <SectionLabel>Plan</SectionLabel>
            <GlassPanel>
              <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <p className="font-serif text-[19px]" style={{ color: GLASS.text }}>
                    Free plan
                  </p>
                  <p className="mt-1 font-sans text-[12.5px] leading-relaxed" style={{ color: GLASS.muted }}>
                    Premium is not enabled in beta. This area shows plan status, reading credits, and limits without payment.
                  </p>
                </div>
                <div className="rounded-[8px] border px-4 py-3" style={{ borderColor: GLASS.border, background: GLASS.panel }}>
                  <p className="font-sans text-[11px] uppercase tracking-[0.14em]" style={{ color: GLASS.faint }}>
                    Limits
                  </p>
                  <p className="mt-1 font-serif text-[14px]" style={{ color: GLASS.text }}>
                    5 readings · 20 chats · 10 voices/day
                  </p>
                </div>
              </div>
            </GlassPanel>
          </section>

          <section>
            <SectionLabel>Trust</SectionLabel>
            <GlassPanel>
              <div className="grid gap-3 sm:grid-cols-2">
                <ActionLink href="/privacy" icon={ShieldCheck} label="Privacy" detail="How Hint handles your data" />
                <ActionLink href="/terms" icon={FileText} label="Terms" detail="Service terms and usage boundaries" />
                <ActionLink href="/contact" icon={Mail} label="Contact" detail={CONTACT_EMAIL} />
                <ActionLink href="/me" icon={Palette} label="Appearance" detail="Theme, language, motion, and sound controls" />
                <ActionLink href="/contact" icon={HelpCircle} label="Help and support" detail="Support, privacy requests, and beta feedback" />
                <button
                  type="button"
                  className="flex items-center gap-3 rounded-[8px] border px-3.5 py-3 text-left"
                  style={{ borderColor: GLASS.border, background: GLASS.panel }}
                  onClick={() => void clearLocalHistory(t("me.clearConfirm"))}
                >
                  <Eraser size={16} color="rgba(214,140,140,0.9)" className="shrink-0" />
                  <span>
                    <span className="block font-serif text-[14px]" style={{ color: "rgba(224,168,168,0.95)" }}>
                      Clear local history
                    </span>
                    <span className="block font-sans text-[11px] leading-snug" style={{ color: "rgba(224,168,168,0.72)" }}>
                      Removes local profile, cards, and saved app state.
                    </span>
                  </span>
                </button>
                <button
                  type="button"
                  className="flex items-center gap-3 rounded-[8px] border px-3.5 py-3 text-left opacity-75"
                  style={{ borderColor: GLASS.border, background: GLASS.panel }}
                >
                  <Download size={16} color={ACCENT.aqua} className="shrink-0" />
                  <span>
                    <span className="block font-serif text-[14px]" style={{ color: GLASS.text }}>
                      Export data
                    </span>
                    <span className="block font-sans text-[11px] leading-snug" style={{ color: GLASS.faint }}>
                      Placeholder for account export.
                    </span>
                  </span>
                </button>
                <div className="flex items-start gap-3 rounded-[8px] border px-3.5 py-3 sm:col-span-2" style={{ borderColor: GLASS.border, background: "rgba(255,255,255,0.025)" }}>
                  <HelpCircle size={15} color={GLASS.faint} className="mt-0.5 shrink-0" />
                  <p className="font-sans text-[11.5px] leading-relaxed" style={{ color: GLASS.faint }}>
                    {LEGAL_DISCLAIMER}
                  </p>
                </div>
              </div>
            </GlassPanel>
          </section>
        </div>
      )}
    </AppScreen>
  );
}
