export const LEGAL_DISCLAIMER =
  "For entertainment and self-reflection only. This is not medical, legal, financial, or mental health advice.";

export const CONTACT_EMAIL = "support@hint.app";

export function LegalNotice() {
  return (
    <aside
      className="fixed inset-x-3 bottom-[116px] z-40 mx-auto max-w-4xl rounded-[8px] border px-3 py-2 md:bottom-auto md:top-[72px]"
      style={{
        color: "var(--hint-muted)",
        background: "color-mix(in srgb, var(--hint-bg) 68%, transparent)",
        borderColor: "var(--hint-border)",
        backdropFilter: "blur(16px)",
        WebkitBackdropFilter: "blur(16px)",
      }}
    >
      <p className="font-sans text-[10.5px] leading-snug md:text-[11px]">
        {LEGAL_DISCLAIMER}
      </p>
    </aside>
  );
}
