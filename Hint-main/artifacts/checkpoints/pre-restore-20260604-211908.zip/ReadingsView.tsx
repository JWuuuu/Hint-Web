import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import { Link } from "wouter";
import {
  Archive,
  BookOpen,
  ChevronRight,
  Heart,
  MessageCircle,
  Moon,
  Sparkles,
  Star,
} from "lucide-react";
import { ACCENT, GLASS } from "../hold/atmosphere";
import { AppScreen, ScreenHeader, GlassPanel, SectionLabel } from "../../components/app/AppChrome";
import { useListReadings } from "@workspace/api-client-react";
import type { ReadingSummary } from "@workspace/api-client-react";
import { getAnonId } from "../../lib/identity";
import { useLanguage, type HintLanguage } from "../../lib/i18n";
import {
  listLocalDailyReadings,
  subscribeToLocalDailyReadings,
} from "./localDailyReadings";

/**
 * ReadingsView — the room's memory. A real archive of every tarot reading the
 * user has sat with, newest first, scoped to their anonymous id.
 */

function fmt(iso: string, todayLabel: string): string {
  const d = new Date(iso);
  const today = new Date();
  if (
    d.getFullYear() === today.getFullYear() &&
    d.getMonth() === today.getMonth() &&
    d.getDate() === today.getDate()
  ) {
    return todayLabel;
  }
  return d.toLocaleDateString(undefined, { month: "short", day: "numeric" });
}

const CARD_NAMES_ZH: Record<string, string> = {
  "The Fool": "愚者",
  "The Magician": "魔术师",
  "The High Priestess": "女祭司",
  "The Empress": "皇后",
  "The Emperor": "皇帝",
  "The Hierophant": "教皇",
  "The Lovers": "恋人",
  "The Chariot": "战车",
  Strength: "力量",
  "The Hermit": "隐士",
  "Wheel of Fortune": "命运之轮",
  Justice: "正义",
  "The Hanged Man": "倒吊人",
  Death: "死神",
  Temperance: "节制",
  "The Devil": "恶魔",
  "The Tower": "高塔",
  "The Star": "星星",
  "The Moon": "月亮",
  "The Sun": "太阳",
  Judgement: "审判",
  "The World": "世界",
};

function displayReading(reading: ReadingSummary, language: HintLanguage) {
  if (language !== "zh") {
    return { cardName: reading.cardName, whisper: reading.whisper };
  }

  const cardName = CARD_NAMES_ZH[reading.cardName] ?? reading.cardName;
  return {
    cardName,
    whisper: `这次解读的核心提示来自「${cardName}」。旧记录会保留原始生成内容，但这里先用中文帮你回到这张牌的重点。`,
  };
}

function ReadingCard({
  reading,
  language,
  todayLabel,
  featured = false,
}: {
  reading: ReadingSummary;
  language: HintLanguage;
  todayLabel: string;
  featured?: boolean;
}) {
  const displayed = displayReading(reading, language);

  return (
    <div
      className={`flex gap-4 rounded-[8px] ${featured ? "px-5 py-5" : "px-4 py-4"}`}
      style={{ background: GLASS.panel, border: `1px solid ${GLASS.border}` }}
    >
      <span
        className="shrink-0 font-serif text-[10px] uppercase tracking-[0.22em] w-14 pt-0.5"
        style={{ color: GLASS.faint }}
      >
        {fmt(reading.createdAt, todayLabel)}
      </span>
      <span
        className="shrink-0 w-px self-stretch"
        style={{ background: GLASS.border }}
        aria-hidden
      />
      <div className="flex-1 min-w-0 flex flex-col gap-1">
        <div className="flex flex-wrap items-baseline gap-x-2 gap-y-1">
          <p
            className={`font-serif ${featured ? "text-[18px]" : "text-[14.5px]"}`}
            style={{ color: GLASS.text }}
          >
            {displayed.cardName}
          </p>
          <p
            className="font-sans text-[10px] uppercase tracking-[0.14em]"
            style={{ color: GLASS.faint }}
          >
            {reading.spreadType}
          </p>
        </div>
        {reading.question && (
          <p className="font-sans text-[12px] leading-snug" style={{ color: GLASS.faint }}>
            {reading.question}
          </p>
        )}
        <p
          className={`font-sans leading-relaxed ${featured ? "text-[13px]" : "text-[12px]"}`}
          style={{ color: GLASS.muted }}
        >
          {displayed.whisper}
        </p>
      </div>
    </div>
  );
}

type Filter = "all" | "daily" | "tarot" | "ask" | "relationships" | "saved";

const FILTERS: { id: Filter; label: string }[] = [
  { id: "all", label: "All" },
  { id: "daily", label: "Daily" },
  { id: "tarot", label: "Tarot" },
  { id: "ask", label: "Ask" },
  { id: "relationships", label: "Relationships" },
  { id: "saved", label: "Saved" },
];

function readingType(reading: ReadingSummary): Filter {
  if (reading.spreadType === "daily-pull" || reading.territory === "daily") return "daily";
  if (reading.spreadType === "ask") return "ask";
  const relationshipSignals = [
    reading.territory,
    reading.spreadType,
    reading.question,
  ]
    .filter(Boolean)
    .join(" ")
    .toLowerCase();
  if (
    /relationship|connection|love|lover|reconciliation|someone|between|them|partner/.test(
      relationshipSignals,
    )
  ) {
    return "relationships";
  }
  return "tarot";
}

function TypeIcon({ type }: { type: Filter }) {
  if (type === "daily") return <Moon size={17} color={ACCENT.gold} />;
  if (type === "ask") return <MessageCircle size={17} color={ACCENT.aqua} />;
  if (type === "relationships") return <Heart size={17} color={ACCENT.lavender} />;
  if (type === "saved") return <Archive size={17} color={ACCENT.gold} />;
  return <Sparkles size={17} color={ACCENT.aqua} />;
}

function ReadingItem({
  reading,
  language,
  todayLabel,
}: {
  reading: ReadingSummary;
  language: HintLanguage;
  todayLabel: string;
}) {
  const displayed = displayReading(reading, language);
  const type = readingType(reading);
  const title =
    reading.question?.trim() ||
    (type === "daily" ? "Daily card" : type === "ask" ? "Ask Hint thread" : "Tarot reading");
  const tag =
    type === "relationships"
      ? "Relationship"
      : type === "daily"
        ? "Daily"
        : type === "ask"
          ? "Ask"
          : "Tarot";
  const openHref = type === "daily" ? "/daily-pull" : type === "ask" ? "/ask" : "/tarot";

  return (
    <div
      className="group flex items-center gap-3 rounded-[8px] border px-4 py-3 transition-colors"
      style={{ background: GLASS.panel, borderColor: GLASS.border }}
    >
      <div
        className="flex h-12 w-10 shrink-0 items-center justify-center rounded-[7px] sm:h-14 sm:w-11"
        style={{
          background:
            type === "daily"
              ? "linear-gradient(160deg, rgba(196,169,98,0.16), rgba(12,15,24,0.64))"
              : type === "relationships"
                ? "linear-gradient(160deg, rgba(178,152,179,0.16), rgba(12,15,24,0.64))"
                : "linear-gradient(160deg, rgba(100,156,158,0.14), rgba(12,15,24,0.64))",
          border: `1px solid ${
            type === "relationships" ? "rgba(178,152,179,0.28)" : GLASS.border
          }`,
        }}
      >
        <TypeIcon type={type} />
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
          <span className="font-sans text-[10px] uppercase tracking-[0.16em]" style={{ color: GLASS.faint }}>
            {fmt(reading.createdAt, todayLabel)}
          </span>
          <span className="font-sans text-[10px] uppercase tracking-[0.16em]" style={{ color: ACCENT.gold }}>
            {tag}
          </span>
        </div>
        <p className="mt-1 truncate font-serif text-[15px]" style={{ color: GLASS.text }}>
          {title}
        </p>
        <p className="mt-1 line-clamp-1 font-sans text-[12px]" style={{ color: GLASS.muted }}>
          {displayed.whisper}
        </p>
      </div>
      <Link
        href={openHref}
        className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-[8px] border"
        aria-label={`Open ${title}`}
        title={`Open ${title}`}
        style={{ color: GLASS.text, borderColor: GLASS.border, background: "rgba(255,255,255,0.035)" }}
      >
        <ChevronRight size={14} />
      </Link>
    </div>
  );
}

function VaultSummary({
  total,
  daily,
  saved,
  latest,
}: {
  total: number;
  daily: number;
  saved: number;
  latest?: ReadingSummary;
}) {
  const cells = [
    { label: "Entries", value: total, icon: Archive },
    { label: "Daily cards", value: daily, icon: Star },
    { label: "Saved", value: saved, icon: BookOpen },
  ];

  return (
    <GlassPanel hero className="mb-7">
      <div className="flex flex-col gap-5 md:flex-row md:items-end md:justify-between">
        <div>
          <p
            className="font-sans text-[11px] font-medium uppercase tracking-[0.14em]"
            style={{ color: ACCENT.aqua }}
          >
            Private vault
          </p>
          <h2 className="mt-2 font-serif text-[27px] leading-tight" style={{ color: GLASS.text }}>
            Saved signals, readings, and notes.
          </h2>
          <p className="mt-2 max-w-lg font-sans text-[13px] leading-relaxed" style={{ color: GLASS.muted }}>
            Your history is arranged for recall: what happened, when it landed, and the line worth keeping.
          </p>
        </div>
        <div className="grid grid-cols-3 gap-2 md:min-w-[300px]">
          {cells.map(({ label, value, icon: Icon }) => (
            <div
              key={label}
              className="rounded-[8px] border px-3 py-3"
              style={{ borderColor: GLASS.border, background: "rgba(255,255,255,0.035)" }}
            >
              <Icon size={15} color={ACCENT.gold} />
              <p className="mt-2 font-serif text-[21px] tabular-nums" style={{ color: GLASS.text }}>
                {value}
              </p>
              <p className="font-sans text-[10px] uppercase tracking-[0.1em]" style={{ color: GLASS.faint }}>
                {label}
              </p>
            </div>
          ))}
        </div>
      </div>
      {latest && (
        <div
          className="mt-5 rounded-[8px] border px-4 py-3"
          style={{ borderColor: GLASS.border, background: "rgba(0,0,0,0.14)" }}
        >
          <p className="font-sans text-[10px] uppercase tracking-[0.14em]" style={{ color: GLASS.faint }}>
            Latest
          </p>
          <p className="mt-1 truncate font-serif text-[15px]" style={{ color: GLASS.text }}>
            {latest.question?.trim() || latest.cardName}
          </p>
        </div>
      )}
    </GlassPanel>
  );
}

function EmptyPanel({ children }: { children: string }) {
  return (
    <div
      className="rounded-[8px] px-4 py-5 text-center font-sans text-[13px] leading-relaxed"
      style={{
        background: "rgba(255,255,255,0.035)",
        border: `1px dashed ${GLASS.border}`,
        color: GLASS.muted,
      }}
    >
      {children}
    </div>
  );
}

export function ReadingsView() {
  const { language, t } = useLanguage();
  const anonId = getAnonId();
  const { data, isLoading } = useListReadings({ anonId });
  const [localReadings, setLocalReadings] = useState<ReadingSummary[]>(() =>
    listLocalDailyReadings(anonId),
  );
  const [filter, setFilter] = useState<Filter>("all");
  const readings = useMemo(() => {
    const apiReadings = (data ?? []) as ReadingSummary[];
    const byId = new Map<string, ReadingSummary>();
    [...localReadings, ...apiReadings].forEach((reading) => {
      byId.set(reading.id, reading);
    });
    return [...byId.values()].sort(
      (a, b) =>
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
    );
  }, [data, localReadings]);
  const savedReadings = useMemo(
    () =>
      ((data ?? []) as ReadingSummary[]).sort(
        (a, b) =>
          new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
      ),
    [data],
  );
  const lastReading = readings[0];
  const dailyCards = readings.filter((reading) => readingType(reading) === "daily");
  const filteredReadings = useMemo(() => {
    if (filter === "all") return readings;
    if (filter === "saved") return savedReadings;
    return readings.filter((reading) => readingType(reading) === filter);
  }, [filter, readings, savedReadings]);
  const recentHistory = filteredReadings.slice(filter === "all" ? 1 : 0, filter === "all" ? 7 : 8);

  useEffect(() => {
    return subscribeToLocalDailyReadings(() => {
      setLocalReadings(listLocalDailyReadings(anonId));
    });
  }, [anonId]);

  return (
    <AppScreen>
      <ScreenHeader
        eyebrow={t("readings.eyebrow")}
        title={t("readings.title")}
        subtitle={t("readings.subtitle")}
      />

      <div className="mb-7">
        <Link
          href="/tarot"
          className="inline-flex h-11 items-center justify-center rounded-[999px] px-5 font-sans text-[14px] font-medium"
          style={{
            color: "#08070B",
            background: "linear-gradient(145deg, rgba(243,212,144,0.98), rgba(122,226,214,0.92))",
            boxShadow: "0 14px 30px rgba(0,0,0,0.22)",
          }}
        >
          {t("readings.new")}
        </Link>
      </div>

      <VaultSummary
        total={readings.length}
        daily={dailyCards.length}
        saved={savedReadings.length}
        latest={lastReading}
      />

      <div className="mb-7 flex flex-wrap gap-2">
        {FILTERS.map((item) => {
          const active = filter === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => setFilter(item.id)}
              className="min-h-9 rounded-full border px-3.5 font-sans text-[12px] font-medium transition-colors"
              style={{
                color: active ? "#08070B" : GLASS.muted,
                background: active
                  ? "linear-gradient(145deg, rgba(243,212,144,0.98), rgba(122,226,214,0.92))"
                  : GLASS.panel,
                borderColor: active ? "transparent" : GLASS.border,
              }}
            >
              {item.label}
            </button>
          );
        })}
      </div>

      {isLoading ? (
        <p className="font-serif italic text-[13px] py-8 text-center" style={{ color: GLASS.muted }}>
          {t("readings.loading")}
        </p>
      ) : readings.length === 0 ? (
        <section className="mb-10">
          <SectionLabel>{t("readings.section")}</SectionLabel>
          <GlassPanel hero>
            <p className="font-sans text-[13px] leading-relaxed text-center mb-4" style={{ color: GLASS.muted }}>
              {t("readings.empty")}
            </p>
            <Link
              href="/tarot"
              className="inline-flex items-center justify-center w-full h-11 rounded-[8px] font-serif text-[12px] uppercase tracking-[0.24em]"
              style={{
                background: "rgba(206,178,110,0.12)",
                border: "1px solid rgba(206,178,110,0.3)",
                color: ACCENT.gold,
              }}
            >
              {t("readings.enter")}
            </Link>
          </GlassPanel>
        </section>
      ) : (
        <>
          <section className="mb-9">
            <SectionLabel>{t("readings.last")}</SectionLabel>
            {lastReading && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, ease: "easeOut" }}
              >
                <ReadingCard
                  reading={lastReading}
                  language={language}
                  todayLabel={t("readings.today")}
                  featured
                />
              </motion.div>
            )}
          </section>

          <section className="mb-9">
            <SectionLabel>{t("readings.recent")}</SectionLabel>
            {recentHistory.length === 0 ? (
              <EmptyPanel>
                {filter === "ask"
                  ? "Ask conversations are not archived yet. When saved threads are available, they will appear here."
                  : t("readings.recentEmpty")}
              </EmptyPanel>
            ) : (
              <div className="flex flex-col gap-3">
                {recentHistory.map((reading, i) => (
                  <motion.div
                    key={reading.id}
                    initial={{ opacity: 0, y: 10 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, amount: 0.3 }}
                    transition={{ duration: 0.6, ease: "easeOut", delay: Math.min(i, 6) * 0.05 }}
                  >
                    <ReadingItem
                      reading={reading}
                      language={language}
                      todayLabel={t("readings.today")}
                    />
                  </motion.div>
                ))}
              </div>
            )}
          </section>

          <section className="mb-10">
            <SectionLabel>Saved daily cards</SectionLabel>
            {dailyCards.length === 0 ? (
              <GlassPanel>
                <div className="flex items-start gap-3">
                  <Archive size={18} color={ACCENT.gold} className="mt-0.5 shrink-0" />
                  <p className="font-sans text-[13px] leading-relaxed" style={{ color: GLASS.muted }}>
                    Save or reveal daily cards and they will collect here as a private reference.
                  </p>
                </div>
              </GlassPanel>
            ) : (
              <div className="flex flex-col gap-3">
                {dailyCards.slice(0, 6).map((reading, i) => (
                  <motion.div
                    key={reading.id}
                    initial={{ opacity: 0, y: 10 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, amount: 0.3 }}
                    transition={{ duration: 0.6, ease: "easeOut", delay: Math.min(i, 6) * 0.05 }}
                  >
                    <ReadingItem
                      reading={reading}
                      language={language}
                      todayLabel={t("readings.today")}
                    />
                  </motion.div>
                ))}
              </div>
            )}
          </section>
        </>
      )}
    </AppScreen>
  );
}
