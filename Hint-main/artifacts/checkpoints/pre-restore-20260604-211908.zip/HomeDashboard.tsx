import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { Link } from "wouter";
import {
  ArrowRight,
  ChevronRight,
  MessageCircle,
  Moon,
  Sparkles,
} from "lucide-react";
import {
  useGetUserStats,
  useListReadings,
  type ReadingSummary,
} from "@workspace/api-client-react";
import { CardBack, GlassPanel } from "../../../components/app/AppChrome";
import { useProfile } from "../../../lib/useProfile";
import { useLanguage } from "../../../lib/i18n";
import { getAnonId } from "../../../lib/identity";
import { getDailyReport } from "../data/dailyReport";
import { listLocalDailyReadings } from "../../readings/localDailyReadings";
import type { DailyReport, DailyScore } from "../types/home.types";

const moodOptions = [
  { value: "low", label: "Low" },
  { value: "steady", label: "Steady" },
  { value: "clear", label: "Clear" },
];

function getGreeting() {
  const hour = new Date().getHours();
  if (hour < 12) return "Good morning";
  if (hour < 18) return "Good afternoon";
  return "Good evening";
}

function formatToday() {
  return new Intl.DateTimeFormat(undefined, {
    weekday: "short",
    month: "short",
    day: "numeric",
  }).format(new Date());
}

function scoreState(score: number) {
  if (score >= 84) return "Clear signal";
  if (score >= 70) return "Steady signal";
  if (score >= 56) return "Soft signal";
  return "Quiet signal";
}

function scoreReason(score: DailyScore) {
  const reason: Record<DailyScore["key"], string> = {
    love: "Sets the tone for close conversations.",
    resources: "Keeps practical choices grounded.",
    work: "Shows where effort can stay focused.",
    focus: "Protects attention from scattering.",
    connection: "Helps decide what needs a reply.",
  };

  return reason[score.key];
}

function HomeGlass({
  children,
  className = "",
  delay = 0,
  hero = false,
}: {
  children: React.ReactNode;
  className?: string;
  delay?: number;
  hero?: boolean;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.62, ease: "easeOut", delay }}
    >
      <GlassPanel hero={hero} className={className}>
        {children}
      </GlassPanel>
    </motion.div>
  );
}

function Greeting({ name }: { name?: string }) {
  const initial = (name?.trim()[0] ?? "H").toUpperCase();

  return (
    <motion.header
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.58, ease: "easeOut" }}
      className="mb-5 flex items-start justify-between gap-4 px-1"
    >
      <div>
        <h1 className="font-serif text-[25px] font-normal leading-[1.15]" style={{ color: "var(--hint-text)" }}>
          {getGreeting()}
          {name ? `, ${name.split(" ")[0]}` : ""}
        </h1>
        <p className="mt-1 font-sans text-[12px] tracking-[0.03em]" style={{ color: "var(--hint-faint)" }}>
          {formatToday()} - night mode
        </p>
      </div>
      <div
        className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border font-serif text-[16px]"
        style={{
          color: "var(--hint-gold-bright)",
          background: "linear-gradient(145deg, var(--hint-navy-2), var(--hint-navy-1))",
          borderColor: "rgba(203,168,102,0.22)",
        }}
      >
        {initial}
      </div>
    </motion.header>
  );
}

function DailyLoopRibbon() {
  const steps = ["Checked in", "Pull card", "Reflect"];

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.58, ease: "easeOut", delay: 0.04 }}
      className="mb-5 flex items-center gap-2 px-1 font-sans text-[11px]"
      style={{ color: "var(--hint-faint)" }}
    >
      {steps.map((step, index) => (
        <div key={step} className="contents">
          <span className="inline-flex shrink-0 items-center gap-2">
            <span
              className="h-[7px] w-[7px] rounded-full"
              style={{
                background: index === 0 ? "var(--hint-aqua)" : "rgba(255,255,255,0.18)",
                boxShadow: index === 0 ? "0 0 8px rgba(134,214,199,0.30)" : "none",
              }}
            />
            <span style={{ color: index === 0 ? "var(--hint-ivory-dim)" : "var(--hint-faint)" }}>
              {step}
            </span>
          </span>
          {index < steps.length - 1 && (
            <span className="h-px flex-1" style={{ background: "rgba(255,255,255,0.10)" }} />
          )}
        </div>
      ))}
    </motion.div>
  );
}

function DailyHintHero({ report }: { report: DailyReport }) {
  const { t } = useLanguage();

  return (
    <HomeGlass hero delay={0.08} className="mb-4 p-0">
      <div
        aria-hidden
        className="absolute right-[-70px] top-[-90px] h-[240px] w-[240px] rounded-full blur-md"
        style={{
          background: "radial-gradient(circle, rgba(134,214,199,0.30), transparent 70%)",
          animation: "hintAuraFloat 9s ease-in-out infinite",
        }}
      />
      <div className="relative p-6">
        <p className="font-sans text-[11px] font-medium uppercase tracking-[0.15em]" style={{ color: "var(--hint-gold)" }}>
          Your hint for tonight
        </p>
        <blockquote className="mt-4 font-serif text-[27px] font-normal leading-[1.34]" style={{ color: "var(--hint-text)" }}>
          {report.title}
        </blockquote>
        <div className="mt-4 flex flex-wrap items-center gap-2 font-sans text-[12.5px]" style={{ color: "var(--hint-faint)" }}>
          <span style={{ color: "var(--hint-gold)" }}>{t("daily.card")}</span>
          <span>-</span>
          <span>{scoreState(report.overallScore)}</span>
        </div>
        <div className="mt-5 flex flex-col gap-3 sm:flex-row">
          <Link
            href="/tarot"
            className="inline-flex min-h-12 items-center justify-center gap-2 rounded-[16px] border px-5 font-sans text-[14px] font-semibold"
            style={{
              color: "#1A1305",
              background: "linear-gradient(180deg, var(--hint-gold-bright), var(--hint-gold))",
              borderColor: "var(--hint-gold-bright)",
            }}
          >
            {t("home.startReading")}
            <ArrowRight size={15} />
          </Link>
          <Link
            href="/ask"
            className="inline-flex min-h-12 items-center justify-center gap-2 rounded-[16px] border px-5 font-sans text-[14px] font-semibold"
            style={{
              color: "var(--hint-gold-bright)",
              background: "rgba(203,168,102,0.08)",
              borderColor: "rgba(203,168,102,0.42)",
            }}
          >
            {t("home.talkFirst")}
          </Link>
        </div>
      </div>
    </HomeGlass>
  );
}

export function TodaySignalRing({ report }: { report: DailyReport }) {
  const [mood, setMood] = useState("steady");
  const radius = 42;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference * (1 - report.overallScore / 100);

  return (
    <HomeGlass delay={0.12} className="h-full min-h-[172px] p-0">
      <div className="flex h-full flex-col p-[18px]">
        <p className="mb-auto font-sans text-[11px] font-medium uppercase tracking-[0.13em]" style={{ color: "var(--hint-ivory-dim)" }}>
          Today&apos;s signal
        </p>
        <div className="mx-auto my-2 grid place-items-center">
          <svg width="112" height="112" viewBox="0 0 112 112" aria-hidden="true">
            <defs>
              <linearGradient id="homeSignalGrad" x1="18" y1="14" x2="94" y2="92">
                <stop stopColor="var(--hint-aqua)" />
                <stop offset="1" stopColor="var(--hint-gold-bright)" />
              </linearGradient>
            </defs>
            <circle cx="56" cy="56" r={radius} fill="none" stroke="rgba(255,255,255,0.10)" strokeWidth="8" />
            <circle
              cx="56"
              cy="56"
              r={radius}
              fill="none"
              stroke="url(#homeSignalGrad)"
              strokeLinecap="round"
              strokeWidth="8"
              strokeDasharray={circumference}
              strokeDashoffset={offset}
              transform="rotate(-90 56 56)"
            />
          </svg>
          <div className="absolute text-center">
            <p className="font-sans text-[30px] font-semibold leading-none tabular-nums" style={{ color: "var(--hint-text)" }}>
              {report.overallScore}
            </p>
            <p className="mt-1 font-sans text-[12px]" style={{ color: "var(--hint-ivory-dim)" }}>
              {scoreState(report.overallScore)}
            </p>
          </div>
        </div>
        <div className="mt-2 grid grid-cols-3 gap-1.5">
          {moodOptions.map((option) => {
            const active = mood === option.value;
            return (
              <button
                key={option.value}
                type="button"
                onClick={() => setMood(option.value)}
                className="h-8 rounded-full border font-sans text-[11px] transition-colors"
                style={{
                  color: active ? "var(--hint-aqua)" : "var(--hint-ivory-dim)",
                  background: active ? "rgba(134,214,199,0.08)" : "transparent",
                  borderColor: active ? "var(--hint-aqua)" : "var(--hint-glass-line)",
                  boxShadow: active ? "0 0 12px rgba(134,214,199,0.16)" : "none",
                }}
              >
                {option.label}
              </button>
            );
          })}
        </div>
      </div>
    </HomeGlass>
  );
}

function DailyCardTile() {
  return (
    <HomeGlass delay={0.16} className="h-full min-h-[172px] p-0">
      <Link href="/daily-pull" className="flex h-full flex-col items-center justify-between p-[18px] text-center">
        <p className="self-start font-sans text-[11px] font-medium uppercase tracking-[0.13em]" style={{ color: "var(--hint-ivory-dim)" }}>
          Daily card
        </p>
        <CardBack />
        <div>
          <p className="font-sans text-[13.5px] font-semibold" style={{ color: "var(--hint-gold-bright)" }}>
            Reveal today&apos;s card
          </p>
          <p className="mt-1 font-sans text-[11px]" style={{ color: "var(--hint-faint)" }}>
            Hidden until you reveal it
          </p>
        </div>
      </Link>
    </HomeGlass>
  );
}

function AskHintBar() {
  return (
    <HomeGlass delay={0.2} className="mb-4 p-0">
      <Link href="/ask" className="flex min-h-[72px] items-center gap-3 p-4">
        <span
          className="flex h-[38px] w-[38px] shrink-0 items-center justify-center rounded-full border"
          style={{
            color: "var(--hint-aqua)",
            background: "linear-gradient(145deg, rgba(134,214,199,0.16), rgba(203,168,102,0.10))",
            borderColor: "var(--hint-glass-line)",
          }}
        >
          <MessageCircle size={17} />
        </span>
        <span className="min-w-0 flex-1">
          <span className="block font-sans text-[14.5px]" style={{ color: "var(--hint-text)" }}>
            Ask Hint
          </span>
          <span className="mt-0.5 block truncate font-sans text-[11.5px]" style={{ color: "var(--hint-faint)" }}>
            Talk through what&apos;s on your mind
          </span>
        </span>
        <ChevronRight size={18} style={{ color: "var(--hint-gold)" }} />
      </Link>
    </HomeGlass>
  );
}

function RecentReadingRow({ reading }: { reading?: ReadingSummary }) {
  const title = reading?.question || "Start a recent thread";
  const body = reading
    ? "A saved reading is waiting in your private vault."
    : "Your saved readings will appear here after you sit with one.";

  return (
    <HomeGlass delay={0.24} className="mb-4 p-0">
      <Link href={reading ? "/readings" : "/tarot"} className="flex min-h-[92px] items-center gap-3 p-4">
        <CardBack compact />
        <span className="min-w-0 flex-1">
          <span className="block font-sans text-[11px] font-medium uppercase tracking-[0.13em]" style={{ color: "var(--hint-ivory-dim)" }}>
            Recent reading
          </span>
          <span className="mt-1 block truncate font-serif text-[16px] font-normal" style={{ color: "var(--hint-text)" }}>
            {title}
          </span>
          <span className="mt-1 line-clamp-1 font-sans text-[12px]" style={{ color: "var(--hint-faint)" }}>
            {body}
          </span>
        </span>
        <ChevronRight size={17} style={{ color: "var(--hint-faint)" }} />
      </Link>
    </HomeGlass>
  );
}

function RitualMiniCard({ stats }: { stats?: { nights: number; readings: number; pulls: number } }) {
  const nights = Math.max(stats?.nights ?? 0, stats?.pulls ?? 0);
  const stars = Math.min(9, Math.max(2, stats?.pulls ?? 0));
  const credits = Math.max(0, 3 - (stats?.readings ?? 0));

  return (
    <HomeGlass delay={0.28} className="mb-4 p-0">
      <div className="p-4">
        <div className="flex items-center justify-between gap-3">
          <div>
            <p className="font-sans text-[11px] font-medium uppercase tracking-[0.13em]" style={{ color: "var(--hint-ivory-dim)" }}>
              Your ritual
            </p>
            <p className="mt-1 font-serif text-[18px] font-normal" style={{ color: "var(--hint-text)" }}>
              {Math.max(3, nights)} nights this week
            </p>
          </div>
          <Moon size={18} style={{ color: "var(--hint-gold)" }} />
        </div>
        <div className="mt-4 grid grid-cols-2 gap-2">
          <div className="rounded-[16px] border p-3" style={{ background: "rgba(255,255,255,0.035)", borderColor: "var(--hint-glass-line)" }}>
            <p className="font-sans text-[11px]" style={{ color: "var(--hint-faint)" }}>Stars</p>
            <p className="mt-1 font-sans text-[18px] font-semibold tabular-nums" style={{ color: "var(--hint-text)" }}>{stars}</p>
          </div>
          <div className="rounded-[16px] border p-3" style={{ background: "rgba(255,255,255,0.035)", borderColor: "var(--hint-glass-line)" }}>
            <p className="font-sans text-[11px]" style={{ color: "var(--hint-faint)" }}>Reading credits</p>
            <p className="mt-1 font-sans text-[18px] font-semibold tabular-nums" style={{ color: "var(--hint-text)" }}>{Math.max(1, credits)}</p>
          </div>
        </div>
        <p className="mt-3 font-sans text-[12px] leading-snug" style={{ color: "var(--hint-muted)" }}>
          1 more Star unlocks a Deep Reading.
        </p>
      </div>
    </HomeGlass>
  );
}

function TodayInsights({ report }: { report: DailyReport }) {
  const luckyByKey = Object.fromEntries(
    report.lucky.map((item) => [item.key, item]),
  );
  const compactSignals = [
    {
      label: luckyByKey.color?.label ?? "Lucky color",
      value: luckyByKey.color?.value ?? "Soft gold",
      reason: luckyByKey.color?.hint ?? "Use it as a visual anchor.",
    },
    {
      label: luckyByKey.number?.label ?? "Lucky number",
      value: luckyByKey.number?.value ?? "3",
      reason: luckyByKey.number?.hint ?? "Use it as a small rhythm.",
    },
    {
      label: luckyByKey.hour?.label ?? "Best hour",
      value: luckyByKey.hour?.value ?? "Tonight",
      reason: luckyByKey.hour?.hint ?? "A better window for reflection.",
    },
    { label: "Do today", value: report.suggestion, reason: "Turns the signal into one concrete step." },
    { label: "Avoid today", value: report.avoid, reason: "Keeps the day from becoming noisy." },
    { label: "Small step", value: report.scores[0]?.label ?? "Focus", reason: report.scores[0] ? scoreReason(report.scores[0]) : "Start with the clearest area." },
  ];

  return (
    <section className="mb-8">
      <div className="mb-3 flex items-center justify-between px-1">
        <h2 className="font-serif text-[20px] font-normal" style={{ color: "var(--hint-text)" }}>
          Today&apos;s insights
        </h2>
        <Sparkles size={16} style={{ color: "var(--hint-gold)" }} />
      </div>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        {compactSignals.map((signal, index) => (
          <HomeGlass key={`${signal.label}-${index}`} delay={0.3 + index * 0.03} className="h-full p-0">
            <div className="p-3">
              <p className="font-sans text-[10.5px] font-medium uppercase tracking-[0.12em]" style={{ color: "var(--hint-faint)" }}>
                {signal.label}
              </p>
              <p className="mt-2 line-clamp-2 font-sans text-[13px] leading-snug" style={{ color: "var(--hint-text)" }}>
                {signal.value}
              </p>
              <p className="mt-2 line-clamp-2 font-sans text-[11px] leading-snug" style={{ color: "var(--hint-muted)" }}>
                {signal.reason}
              </p>
            </div>
          </HomeGlass>
        ))}
      </div>
    </section>
  );
}

export function HomeDashboard() {
  const { language } = useLanguage();
  const { profile } = useProfile();
  const anonId = getAnonId();
  const report = useMemo(
    () => getDailyReport({ anonId, language }),
    [anonId, language],
  );
  const localReadings = useMemo(() => listLocalDailyReadings(anonId), [anonId]);
  const readingsQuery = useListReadings({ anonId });
  const statsQuery = useGetUserStats({ anonId });
  const recentReading = localReadings[0] ?? readingsQuery.data?.[0];

  return (
    <div className="h-full w-full overflow-y-auto overscroll-none pb-36">
      <style>
        {`@keyframes hintAuraFloat{0%,100%{transform:translateY(0)}50%{transform:translateY(16px)}}`}
      </style>
      <main className="mx-auto w-full max-w-[430px] px-5 pt-6 sm:max-w-2xl md:pt-8">
        <Greeting name={profile?.name} />
        <DailyLoopRibbon />
        <DailyHintHero report={report} />

        <section className="mb-4 grid grid-cols-[1.05fr_1fr] gap-3">
          <TodaySignalRing report={report} />
          <DailyCardTile />
        </section>

        <AskHintBar />
        <RecentReadingRow reading={recentReading} />
        <RitualMiniCard stats={statsQuery.data} />
        <TodayInsights report={report} />
      </main>
    </div>
  );
}
