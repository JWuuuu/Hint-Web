export type RitualPhase =
  | "rest"
  | "wash"
  | "gather"
  | "cut"
  | "stack"
  | "spread"
  | "choose"
  | "reveal";

export type CardOrientation = "upright" | "reversed";

export type HiddenCardIdentity = {
  cardId: string;
  name: string;
  arcana: "major" | "minor";
  suit?: "wands" | "cups" | "swords" | "pentacles";
  orientation: CardOrientation;
  keywords: string[];
};

export type CardTransform = {
  x: number;
  y: number;
  rotate: number;
  scale: number;
  opacity: number;
  zIndex: number;
};

export type RitualCard = {
  visualId: string;
  visualIndex: number;
  hiddenIdentity: HiddenCardIdentity;
  transform: CardTransform;
  selected: boolean;
  revealed: boolean;
};

export type PhaseCopy = {
  title: string;
  body: string;
  action: string;
};
