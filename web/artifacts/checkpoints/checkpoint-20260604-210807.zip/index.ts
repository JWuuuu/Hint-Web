export { TarotRitualRoom as TarotRoom } from "./components/TarotRitualRoom";
