import { useMemo, useState } from "react";
import { Link } from "wouter";
import { RitualCard } from "./RitualCard";
import {
  PHASE_COPY,
  REQUIRED_SELECTION_COUNT,
  RITUAL_PHASES,
  createRitualDeck,
  getNextPhase,
  getPhaseIndex,
  layoutCardsForPhase,
} from "../logic/ritualPhaseEngine";
import type { RitualPhase } from "../logic/ritualTypes";

export function TarotRitualRoom() {
  const [baseDeck] = useState(() => createRitualDeck());
  const [phase, setPhase] = useState<RitualPhase>("rest");
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [revealedIds, setRevealedIds] = useState<string[]>([]);

  const cards = useMemo(
    () => layoutCardsForPhase(baseDeck, phase, selectedIds, revealedIds),
    [baseDeck, phase, revealedIds, selectedIds],
  );

  const selectedCards = selectedIds
    .map((id) => cards.find((card) => card.visualId === id))
    .filter((card): card is NonNullable<typeof card> => Boolean(card));

  const copy = PHASE_COPY[phase];
  const phaseIndex = getPhaseIndex(phase);
  const revealComplete = revealedIds.length === REQUIRED_SELECTION_COUNT;
  const actionDisabled =
    phase === "choose" && selectedIds.length !== REQUIRED_SELECTION_COUNT;

  function advancePhase() {
    if (phase === "reveal") return;
    setPhase(getNextPhase(phase));
  }

  function toggleSelected(visualId: string) {
    if (phase !== "choose") return;
    setSelectedIds((current) => {
      if (current.includes(visualId)) {
        return current.filter((id) => id !== visualId);
      }
      if (current.length >= REQUIRED_SELECTION_COUNT) return current;
      return [...current, visualId];
    });
  }

  function revealCard(visualId: string) {
    if (phase !== "reveal" || !selectedIds.includes(visualId)) return;
    setRevealedIds((current) =>
      current.includes(visualId) ? current : [...current, visualId],
    );
  }

  return (
    <div className="relative min-h-full overflow-hidden bg-[#080B14] text-[#F2ECDE]">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(600px_360px_at_78%_4%,#142a40_0%,transparent_58%),radial-gradient(520px_420px_at_12%_96%,#20183a_0%,transparent_55%),linear-gradient(180deg,#0A0F1C_0%,#0B1120_48%,#080B14_100%)]" />
      <div className="pointer-events-none absolute inset-0 opacity-60 [background-image:radial-gradient(circle_at_18%_22%,rgba(255,255,255,0.45)_0_1px,transparent_1px),radial-gradient(circle_at_70%_16%,rgba(255,255,255,0.35)_0_1px,transparent_1px),radial-gradient(circle_at_84%_62%,rgba(255,255,255,0.28)_0_1px,transparent_1px),radial-gradient(circle_at_34%_78%,rgba(255,255,255,0.32)_0_1px,transparent_1px)] [background-size:90px_120px,130px_160px,110px_150px,150px_170px]" />
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-56 bg-[radial-gradient(ellipse_at_center,rgba(242,236,222,0.08),transparent_68%)] blur-2xl" />

      <Link
        href="/"
        className="absolute left-5 top-5 z-30 font-sans text-[11px] uppercase tracking-[0.22em] text-[#C4BCA9]/80"
      >
        Home
      </Link>

      <section className="relative z-10 flex min-h-full flex-col px-4 pb-24 pt-16 sm:px-8">
        <header className="mx-auto max-w-md text-center">
          <p className="font-sans text-[11px] uppercase tracking-[0.24em] text-[#CBA866]">
            The Tarot Room
          </p>
          <h1 className="mt-3 font-serif text-[26px] font-normal leading-tight text-[#F2ECDE]">
            {copy.title}
          </h1>
          <p className="mx-auto mt-3 min-h-[42px] max-w-sm font-sans text-[14px] leading-relaxed text-[#8C92A3]">
            {phase === "choose"
              ? selectedIds.length < REQUIRED_SELECTION_COUNT
                ? `Tap three cards that pull at you. ${REQUIRED_SELECTION_COUNT - selectedIds.length} more.`
                : "Three chosen. Reveal when ready."
              : copy.body}
          </p>
        </header>

        <div className="relative mx-auto mt-5 h-[420px] w-full max-w-[430px] flex-1 overflow-hidden rounded-[24px] border border-white/10 bg-white/[0.035] shadow-[inset_0_1px_0_rgba(255,255,255,0.16),0_24px_80px_rgba(0,0,0,0.36)] backdrop-blur-[22px] sm:h-[500px]">
          <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-[linear-gradient(90deg,transparent,rgba(255,255,255,0.28),transparent)]" />
          <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_42%,rgba(203,168,102,0.10),transparent_48%)]" />
          {phase === "cut" && (
            <div className="pointer-events-none absolute left-0 right-0 top-[64%] z-20 mx-auto flex max-w-[340px] justify-between px-8 font-sans text-[10px] uppercase tracking-[0.18em] text-[#C4BCA9]/70">
              <span>Past</span>
              <span>Present</span>
              <span>What waits</span>
            </div>
          )}
          <div className="absolute inset-0">
            {cards.map((card) => (
              <RitualCard
                key={card.visualId}
                card={card}
                phaseIsChoose={phase === "choose"}
                phaseIsReveal={phase === "reveal"}
                onChoose={toggleSelected}
                onReveal={revealCard}
              />
            ))}
          </div>

          {phase === "reveal" && revealComplete && (
            <div className="absolute inset-x-4 bottom-4 z-40 rounded-[18px] border border-[#86D6C7]/20 bg-[#0A0F1C]/88 p-4 shadow-[0_18px_42px_rgba(0,0,0,0.45)] backdrop-blur-xl">
              <p className="font-sans text-[10px] uppercase tracking-[0.22em] text-[#86D6C7]">
                Mock reading
              </p>
              <div className="mt-3 rounded-[14px] border border-white/10 bg-white/[0.045] px-4 py-3 font-sans text-[14px] leading-relaxed text-[#F2ECDE]">
                These three cards are being held for a future reading flow. For now:
                {selectedCards.map((card) => ` ${card.hiddenIdentity.name}`).join(", ")}.
              </div>
              <div className="mt-3 rounded-[14px] border border-[#CBA866]/20 bg-[#CBA866]/[0.08] px-4 py-3 font-sans text-[13px] leading-relaxed text-[#C4BCA9]">
                Placeholder only. No chat handoff, backend request, or AI call has been made.
              </div>
            </div>
          )}
        </div>

        <footer className="mx-auto mt-4 w-full max-w-md">
          <div className="mb-4 flex items-center justify-center gap-2">
            {RITUAL_PHASES.map((item, index) => (
              <span
                key={item}
                className={`h-1.5 rounded-full transition-all duration-300 ${
                  index === phaseIndex
                    ? "w-6 bg-[#CBA866]"
                    : index < phaseIndex
                      ? "w-1.5 bg-[#86D6C7]"
                      : "w-1.5 bg-white/16"
                }`}
              />
            ))}
          </div>
          {phase !== "reveal" ? (
            <button
              type="button"
              disabled={actionDisabled}
              onClick={advancePhase}
              className="h-14 w-full rounded-[16px] border border-[#CBA866] bg-[linear-gradient(180deg,rgba(203,168,102,0.18),rgba(203,168,102,0.06))] font-sans text-[15px] font-semibold tracking-[0.03em] text-[#E6CB8E] transition active:scale-[0.985] disabled:cursor-not-allowed disabled:opacity-40"
            >
              {copy.action}
            </button>
          ) : (
            <div className="text-center font-sans text-[12px] uppercase tracking-[0.2em] text-[#C4BCA9]/60">
              {revealComplete ? "Reading placeholder ready" : "Tap each selected card"}
            </div>
          )}
        </footer>
      </section>
    </div>
  );
}
