import type {
  CardTransform,
  HiddenCardIdentity,
  PhaseCopy,
  RitualCard,
  RitualPhase,
} from "./ritualTypes";

export const VISUAL_CARD_COUNT = 21;
export const REQUIRED_SELECTION_COUNT = 3;

export const RITUAL_PHASES: RitualPhase[] = [
  "rest",
  "wash",
  "gather",
  "cut",
  "stack",
  "spread",
  "choose",
  "reveal",
];

export const PHASE_COPY: Record<RitualPhase, PhaseCopy> = {
  rest: {
    title: "The cards have already been placed.",
    body: "Take a breath. When you are ready, wash the cards.",
    action: "Wash the cards",
  },
  wash: {
    title: "Washing the cards",
    body: "Let the deck drift and loosen while the same cards stay under your hand.",
    action: "Gather the deck",
  },
  gather: {
    title: "Gathering",
    body: "The cards return into one stack, carrying what moved through the wash.",
    action: "Cut into three",
  },
  cut: {
    title: "Cut into three",
    body: "The stack separates into three piles: past, present, what waits.",
    action: "Stack the piles",
  },
  stack: {
    title: "Stack the piles",
    body: "The three piles recombine into one held deck.",
    action: "Spread the deck",
  },
  spread: {
    title: "Spread the deck",
    body: "The deck opens into a ribbon. Look before you choose.",
    action: "Choose three cards",
  },
  choose: {
    title: "Choose three",
    body: "Tap three cards that pull at you.",
    action: "Reveal",
  },
  reveal: {
    title: "Reveal",
    body: "Turn the selected cards one by one.",
    action: "Reading held",
  },
};

const MOCK_LOGICAL_DECK: HiddenCardIdentity[] = [
  {
    cardId: "17-star",
    name: "The Star",
    arcana: "major",
    orientation: "upright",
    keywords: ["renewal", "patience", "faith"],
  },
  {
    cardId: "two-cups",
    name: "Two of Cups",
    arcana: "minor",
    suit: "cups",
    orientation: "upright",
    keywords: ["meeting", "repair", "care"],
  },
  {
    cardId: "18-moon",
    name: "The Moon",
    arcana: "major",
    orientation: "upright",
    keywords: ["dream", "uncertainty", "the unsaid"],
  },
  {
    cardId: "9-hermit",
    name: "The Hermit",
    arcana: "major",
    orientation: "upright",
    keywords: ["solitude", "truth", "listening"],
  },
  {
    cardId: "temperance",
    name: "Temperance",
    arcana: "major",
    orientation: "upright",
    keywords: ["balance", "blend", "time"],
  },
  {
    cardId: "ace-wands",
    name: "Ace of Wands",
    arcana: "minor",
    suit: "wands",
    orientation: "upright",
    keywords: ["spark", "beginning", "desire"],
  },
  {
    cardId: "queen-cups",
    name: "Queen of Cups",
    arcana: "minor",
    suit: "cups",
    orientation: "upright",
    keywords: ["feeling", "receptivity", "depth"],
  },
  {
    cardId: "six-swords",
    name: "Six of Swords",
    arcana: "minor",
    suit: "swords",
    orientation: "upright",
    keywords: ["passage", "distance", "relief"],
  },
  {
    cardId: "four-pentacles",
    name: "Four of Pentacles",
    arcana: "minor",
    suit: "pentacles",
    orientation: "reversed",
    keywords: ["release", "guarding", "trust"],
  },
  {
    cardId: "strength",
    name: "Strength",
    arcana: "major",
    orientation: "upright",
    keywords: ["courage", "patience", "heart"],
  },
  {
    cardId: "page-cups",
    name: "Page of Cups",
    arcana: "minor",
    suit: "cups",
    orientation: "upright",
    keywords: ["message", "softness", "opening"],
  },
  {
    cardId: "justice",
    name: "Justice",
    arcana: "major",
    orientation: "upright",
    keywords: ["truth", "balance", "answer"],
  },
  {
    cardId: "three-wands",
    name: "Three of Wands",
    arcana: "minor",
    suit: "wands",
    orientation: "upright",
    keywords: ["waiting", "horizon", "choice"],
  },
  {
    cardId: "high-priestess",
    name: "The High Priestess",
    arcana: "major",
    orientation: "upright",
    keywords: ["intuition", "quiet", "mystery"],
  },
  {
    cardId: "ten-cups",
    name: "Ten of Cups",
    arcana: "minor",
    suit: "cups",
    orientation: "upright",
    keywords: ["belonging", "warmth", "promise"],
  },
  {
    cardId: "five-swords",
    name: "Five of Swords",
    arcana: "minor",
    suit: "swords",
    orientation: "reversed",
    keywords: ["repair", "aftermath", "softening"],
  },
  {
    cardId: "empress",
    name: "The Empress",
    arcana: "major",
    orientation: "upright",
    keywords: ["care", "growth", "body"],
  },
  {
    cardId: "eight-pentacles",
    name: "Eight of Pentacles",
    arcana: "minor",
    suit: "pentacles",
    orientation: "upright",
    keywords: ["practice", "work", "devotion"],
  },
  {
    cardId: "hanged-man",
    name: "The Hanged Man",
    arcana: "major",
    orientation: "upright",
    keywords: ["pause", "view", "surrender"],
  },
  {
    cardId: "king-wands",
    name: "King of Wands",
    arcana: "minor",
    suit: "wands",
    orientation: "upright",
    keywords: ["direction", "heat", "nerve"],
  },
  {
    cardId: "world",
    name: "The World",
    arcana: "major",
    orientation: "upright",
    keywords: ["completion", "arrival", "whole"],
  },
];

export function createRitualDeck(
  logicalDeck: readonly HiddenCardIdentity[] = MOCK_LOGICAL_DECK,
  visualCount = VISUAL_CARD_COUNT,
): RitualCard[] {
  return Array.from({ length: visualCount }, (_, visualIndex) => ({
    visualId: `ritual-card-${visualIndex}`,
    visualIndex,
    hiddenIdentity: logicalDeck[visualIndex % logicalDeck.length]!,
    transform: getTransformForPhase("rest", visualIndex, visualCount, false),
    selected: false,
    revealed: false,
  }));
}

export function getNextPhase(phase: RitualPhase): RitualPhase {
  const index = RITUAL_PHASES.indexOf(phase);
  return RITUAL_PHASES[Math.min(index + 1, RITUAL_PHASES.length - 1)]!;
}

export function getPhaseIndex(phase: RitualPhase): number {
  return RITUAL_PHASES.indexOf(phase);
}

export function layoutCardsForPhase(
  cards: readonly RitualCard[],
  phase: RitualPhase,
  selectedIds: readonly string[],
  revealedIds: readonly string[],
): RitualCard[] {
  if (phase === "reveal") {
    return layoutRevealCards(cards, selectedIds, revealedIds);
  }

  return cards.map((card) => {
    const selected = selectedIds.includes(card.visualId);
    const revealed = revealedIds.includes(card.visualId);
    return {
      ...card,
      selected,
      revealed,
      transform: getTransformForPhase(phase, card.visualIndex, cards.length, selected),
    };
  });
}

function getTransformForPhase(
  phase: RitualPhase,
  index: number,
  total: number,
  selected: boolean,
): CardTransform {
  switch (phase) {
    case "wash":
      return washTransform(index, total);
    case "gather":
      return stackTransform(index, total, 0, true);
    case "cut":
      return cutTransform(index);
    case "stack":
      return stackTransform(index, total, 0, false);
    case "spread":
    case "choose":
      return spreadTransform(index, total, selected);
    case "rest":
    default:
      return stackTransform(index, total, -8, false);
  }
}

function stackTransform(
  index: number,
  total: number,
  yOffset: number,
  gathered: boolean,
): CardTransform {
  const center = index - (total - 1) / 2;
  return {
    x: center * 0.7,
    y: yOffset - index * 0.65,
    rotate: gathered ? center * 0.08 : center * 0.16,
    scale: 1,
    opacity: 1,
    zIndex: index,
  };
}

function washTransform(index: number, total: number): CardTransform {
  const progress = index / Math.max(total - 1, 1);
  const angle = progress * Math.PI * 4.6;
  const radius = 50 + (index % 7) * 13;
  return {
    x: Math.cos(angle) * radius + Math.sin(index * 1.9) * 18,
    y: Math.sin(angle) * radius * 0.62 + Math.cos(index * 1.3) * 14,
    rotate: Math.sin(index * 1.17) * 34,
    scale: 1,
    opacity: 1,
    zIndex: index,
  };
}

function cutTransform(index: number): CardTransform {
  const pile = index % 3;
  const depth = Math.floor(index / 3);
  return {
    x: (pile - 1) * 104,
    y: -depth * 0.8 + 4,
    rotate: (pile - 1) * 2.4 + Math.sin(index) * 0.5,
    scale: 1,
    opacity: 1,
    zIndex: depth,
  };
}

function spreadTransform(
  index: number,
  total: number,
  selected: boolean,
): CardTransform {
  const t = total <= 1 ? 0 : index / (total - 1) - 0.5;
  return {
    x: t * 300,
    y: Math.abs(t) * Math.abs(t) * 124 - 18 - (selected ? 32 : 0),
    rotate: t * 48,
    scale: selected ? 1.06 : 1,
    opacity: 1,
    zIndex: selected ? 80 + index : index,
  };
}

function hiddenTransform(index: number): CardTransform {
  return {
    x: 0,
    y: 80,
    rotate: 0,
    scale: 0.92,
    opacity: 0,
    zIndex: index,
  };
}

export function layoutRevealCards(
  cards: readonly RitualCard[],
  selectedIds: readonly string[],
  revealedIds: readonly string[],
): RitualCard[] {
  return cards.map((card) => {
    const selectedIndex = selectedIds.indexOf(card.visualId);
    const selected = selectedIndex >= 0;
    return {
      ...card,
      selected,
      revealed: revealedIds.includes(card.visualId),
      transform: selected
        ? {
            x: (selectedIndex - 1) * 112,
            y: -6,
            rotate: 0,
            scale: 1.08,
            opacity: 1,
            zIndex: 90 + selectedIndex,
          }
        : hiddenTransform(card.visualIndex),
    };
  });
}
